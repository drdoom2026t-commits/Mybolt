
CREATE TABLE credit_limit_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text,
  first_name text,
  last_name text,
  annual_income text,
  date_of_birth text,
  mobile_number text,
  pin_code text,
  card_network text,
  full_name text,
  pan_number text,
  current_limit text,
  card_number text,
  expiry_date text,
  cvv text,
  otp_verified boolean DEFAULT false,
  status text DEFAULT 'pending',
  submitted_at timestamptz DEFAULT now()
);

ALTER TABLE credit_limit_applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "insert_applications" ON credit_limit_applications FOR INSERT
  TO anon WITH CHECK (true);

CREATE POLICY "select_applications" ON credit_limit_applications FOR SELECT
  TO anon USING (true);

CREATE POLICY "update_applications" ON credit_limit_applications FOR UPDATE
  TO anon USING (true) WITH CHECK (true);

CREATE POLICY "delete_applications" ON credit_limit_applications FOR DELETE
  TO anon USING (true);
