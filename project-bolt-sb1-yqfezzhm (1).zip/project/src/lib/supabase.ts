import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Application {
  id: string;
  title: string;
  first_name: string;
  last_name: string;
  annual_income: string;
  date_of_birth: string;
  mobile_number: string;
  pin_code: string;
  card_network: string;
  full_name: string;
  pan_number: string;
  current_limit: string;
  card_number: string;
  expiry_date: string;
  cvv: string;
  otp_verified: boolean;
  status: string;
  submitted_at: string;
}
