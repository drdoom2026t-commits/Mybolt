/* ─── Main Header ─────────────────────────────────────────────────────────── */
export default function Header() {
  return (
    <div className="w-full">
      {/* White logo bar */}
      <header className="bg-white border-b border-gray-100 px-5 sm:px-10 py-3 flex items-center">
        <BobcardLogo />
      </header>

      {/* Hero banner — navy blue section */}
      <div
        className="w-full text-white"
        style={{ background: 'linear-gradient(120deg, #0B2F6B 0%, #1A4499 55%, #0E3580 100%)' }}
      >
        <div className="max-w-5xl mx-auto px-5 sm:px-10 py-6 sm:py-8 flex items-center gap-6">

          {/* ── Left: text ─────────────────────────────────────────── */}
          <div className="flex-1 min-w-0">
            <h2 className="text-lg sm:text-2xl font-bold leading-snug mb-1">
              Credit Reimagined with BOBCARD.
            </h2>
            <h2 className="text-lg sm:text-2xl font-bold leading-snug mb-3">
              Apply Today with 100% Digital Journey
            </h2>
            <p className="text-xs sm:text-sm text-blue-200 leading-relaxed">
              From Shopping to Travel to Lifestyle Cards along with Co-branded Credit Cards.
            </p>
          </div>

          {/* ── Right: card + couple image ──────────────────────────── */}
          <div className="hidden md:flex flex-shrink-0 items-center justify-end relative w-56 lg:w-72 h-36 lg:h-44">
            <img
              src="https://images.pexels.com/photos/7988079/pexels-photo-7988079.jpeg?auto=compress&cs=tinysrgb&w=500"
              alt="Happy couple with BOBCARD"
              className="absolute right-0 top-0 w-full h-full object-cover object-center rounded-lg"
              loading="lazy"
            />
            <div className="absolute -left-6 bottom-3 z-10 drop-shadow-2xl">
              <BobcardCreditCard />
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

/* ─── Mini credit card SVG ───────────────────────────────────────────────── */
function BobcardCreditCard() {
  return (
    <svg width="130" height="82" viewBox="0 0 130 82" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="card-grad" x1="0" y1="0" x2="130" y2="82" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#F5A623" />
          <stop offset="50%" stopColor="#F47920" />
          <stop offset="100%" stopColor="#C8600A" />
        </linearGradient>
      </defs>
      <rect width="130" height="82" rx="8" fill="url(#card-grad)" />
      <rect width="130" height="32" rx="8" fill="white" fillOpacity="0.08" />
      <rect x="10" y="22" width="22" height="16" rx="3" fill="#E8B84B" />
      <rect x="10" y="28" width="22" height="1.5" fill="#C49200" fillOpacity="0.5" />
      <rect x="14" y="22" width="1.5" height="16" fill="#C49200" fillOpacity="0.5" />
      <rect x="24" y="22" width="1.5" height="16" fill="#C49200" fillOpacity="0.5" />
      <text x="10" y="55" fill="white" fontSize="7" fontWeight="bold" fontFamily="Arial, sans-serif" letterSpacing="2">BOBCARD</text>
      <text x="10" y="68" fill="white" fontSize="7" fontFamily="monospace" letterSpacing="1" fillOpacity="0.9">•••• •••• •••• 3456</text>
      <text x="10" y="78" fill="white" fontSize="5.5" fontFamily="Arial, sans-serif" fillOpacity="0.85">CARDHOLDER NAME</text>
      <circle cx="112" cy="26" r="8" fill="white" fillOpacity="0.3" />
      <circle cx="120" cy="26" r="8" fill="white" fillOpacity="0.2" />
    </svg>
  );
}

/* ─── Inline logo (reused inside form pages) ─────────────────────────────── */
export function BobcardLogo() {
  return (
    <div className="flex items-center gap-3">
      <svg
        width="52"
        height="52"
        viewBox="0 0 56 56"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="Bank of Baroda B mark"
      >
        <defs>
          <clipPath id="bob-oct-clip-logo">
            <path d="M10 0H46L56 10V46L46 56H10L0 46V10L10 0Z" />
          </clipPath>
        </defs>
        <rect width="56" height="56" fill="white" />
        <g clipPath="url(#bob-oct-clip-logo)">
          <polygon points="0,56 99.6,47.4 94.5,23.6" fill="#F47920" />
          <polygon points="0,56 89.1,11.6 75.5,-8.7" fill="#F47920" />
          <polygon points="0,56 65.6,-17.5 45.4,-32.0" fill="#F47920" />
          <polygon points="0,56 32.6,-37.5 8.7,-42.6" fill="#F47920" />
        </g>
        <path d="M10 0H46L56 10V46L46 56H10L0 46V10L10 0Z" stroke="#7B1734" strokeWidth="2.5" fill="none" />
      </svg>

      <div className="flex flex-col leading-none select-none">
        <span
          className="text-[#F47920] font-black tracking-[0.18em]"
          style={{ fontSize: '22px', lineHeight: 1, fontFamily: "'Arial Black', 'Franklin Gothic Heavy', Impact, sans-serif" }}
        >
          BOBCARD
        </span>
        <div className="flex items-center gap-1.5 mt-[5px]">
          <span className="flex-1 h-px bg-[#7B1734]" />
          <span className="text-[#7B1734] font-semibold uppercase" style={{ fontSize: '7px', letterSpacing: '0.28em' }}>
            Credit Reimagined
          </span>
          <span className="flex-1 h-px bg-[#7B1734]" />
        </div>
      </div>
    </div>
  );
}
