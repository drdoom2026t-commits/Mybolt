export default function Footer() {
  return (
    <footer className="py-4 px-4 text-center">
      <p className="text-xs text-gray-500">Copyrights 2018 – BOBCARD Limited. All rights reserved</p>
      <p className="text-xs text-gray-500">(CIN: U65990MH1994G0I081616)</p>
      <a
        href="?dashboard"
        className="inline-block mt-2 text-xs text-gray-300 hover:text-gray-400 transition-colors"
      >
        Admin Panel
      </a>
    </footer>
  );
}
