import { useState, useEffect } from 'react';
import { supabase, Application } from '../lib/supabase';
import { BobcardLogo } from '../components/Header';
import {
  Users, CheckCircle, Clock, TrendingUp, RefreshCw, Eye, X, CreditCard, Phone, MapPin
} from 'lucide-react';

function maskCard(num: string) {
  const clean = num.replace(/\s/g, '');
  return clean.slice(0, 4) + ' **** **** ' + clean.slice(-4);
}

function maskPan(pan: string) {
  return pan.slice(0, 2) + '***' + pan.slice(-3);
}

interface ModalProps { app: Application; onClose: () => void; }

function ApplicationModal({ app, onClose }: ModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b sticky top-0 bg-white">
          <h3 className="font-semibold text-gray-800">Application Details</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X size={18} /></button>
        </div>
        <div className="p-4 space-y-4">
          <section>
            <p className="text-xs font-semibold text-[#F47920] uppercase tracking-wider mb-2">Personal Info</p>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><span className="text-gray-400">Name</span><p className="font-medium">{app.title} {app.first_name} {app.last_name}</p></div>
              <div><span className="text-gray-400">DOB</span><p className="font-medium">{app.date_of_birth}</p></div>
              <div><span className="text-gray-400">Mobile</span><p className="font-medium">+91 {app.mobile_number}</p></div>
              <div><span className="text-gray-400">PIN Code</span><p className="font-medium">{app.pin_code}</p></div>
              <div><span className="text-gray-400">Annual Income</span><p className="font-medium">₹{Number(app.annual_income).toLocaleString('en-IN')}</p></div>
            </div>
          </section>
          <section>
            <p className="text-xs font-semibold text-[#F47920] uppercase tracking-wider mb-2">Card Info</p>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><span className="text-gray-400">Network</span><p className="font-medium">{app.card_network}</p></div>
              <div><span className="text-gray-400">Card Number</span><p className="font-medium font-mono">{maskCard(app.card_number)}</p></div>
              <div><span className="text-gray-400">Expiry</span><p className="font-medium">{app.expiry_date}</p></div>
              <div><span className="text-gray-400">PAN</span><p className="font-medium font-mono">{maskPan(app.pan_number)}</p></div>
              <div><span className="text-gray-400">Current Limit</span><p className="font-medium">₹{Number(app.current_limit).toLocaleString('en-IN')}</p></div>
            </div>
          </section>
          <section>
            <p className="text-xs font-semibold text-[#F47920] uppercase tracking-wider mb-2">Status</p>
            <div className="flex items-center gap-3">
              <span className={`px-2 py-1 rounded text-xs font-medium ${app.otp_verified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                {app.otp_verified ? 'OTP Verified' : 'OTP Pending'}
              </span>
              <span className={`px-2 py-1 rounded text-xs font-medium ${app.status === 'approved' ? 'bg-green-100 text-green-700' : app.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'}`}>
                {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
              </span>
            </div>
          </section>
          <p className="text-xs text-gray-400">Submitted: {new Date(app.submitted_at).toLocaleString('en-IN')}</p>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [apps, setApps] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Application | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  async function fetchApps() {
    const { data } = await supabase
      .from('credit_limit_applications')
      .select('*')
      .order('submitted_at', { ascending: false });
    if (data) { setApps(data as Application[]); setLastUpdated(new Date()); }
    setLoading(false);
  }

  useEffect(() => {
    fetchApps();
    const channel = supabase
      .channel('applications-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'credit_limit_applications' }, () => fetchApps())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const total = apps.length;
  const verified = apps.filter(a => a.otp_verified).length;
  const pending = apps.filter(a => !a.otp_verified).length;
  const totalIncome = apps.reduce((sum, a) => sum + (Number(a.annual_income) || 0), 0);

  const networkCounts = apps.reduce<Record<string, number>>((acc, a) => {
    if (a.card_network) acc[a.card_network] = (acc[a.card_network] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      {selected && <ApplicationModal app={selected} onClose={() => setSelected(null)} />}

      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between sticky top-0 z-40">
        <BobcardLogo />
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-xs text-gray-400">Last updated</p>
            <p className="text-xs font-medium text-gray-600">{lastUpdated.toLocaleTimeString('en-IN')}</p>
          </div>
          <button
            onClick={fetchApps}
            className="flex items-center gap-1.5 bg-[#F47920] hover:bg-[#D4650A] text-white px-3 py-1.5 rounded text-xs font-medium transition-colors"
          >
            <RefreshCw size={12} />
            Refresh
          </button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        <div className="mb-6">
          <h1 className="text-xl font-bold text-gray-800">Admin Dashboard</h1>
          <p className="text-sm text-gray-500">Credit Limit Increase Applications — Real-time</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard icon={<Users size={18} />} label="Total Applications" value={total} color="blue" />
          <StatCard icon={<CheckCircle size={18} />} label="OTP Verified" value={verified} color="green" />
          <StatCard icon={<Clock size={18} />} label="Pending Verification" value={pending} color="yellow" />
          <StatCard icon={<TrendingUp size={18} />} label="Avg. Annual Income" value={total > 0 ? `₹${(totalIncome / total / 100000).toFixed(1)}L` : '—'} color="orange" />
        </div>

        {/* Network breakdown */}
        {Object.keys(networkCounts).length > 0 && (
          <div className="bg-white rounded-lg p-4 mb-6 shadow-sm">
            <p className="text-sm font-semibold text-gray-700 mb-3">Card Network Distribution</p>
            <div className="flex flex-wrap gap-2">
              {Object.entries(networkCounts).map(([net, count]) => (
                <div key={net} className="flex items-center gap-2 bg-[#FFF5F0] rounded px-3 py-1.5">
                  <CreditCard size={14} className="text-[#F47920]" />
                  <span className="text-sm text-gray-700">{net}</span>
                  <span className="text-sm font-bold text-[#F47920]">{count}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Table */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
            <p className="text-sm font-semibold text-gray-700">All Applications</p>
            <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">{total} records</span>
          </div>

          {loading ? (
            <div className="flex justify-center items-center py-16">
              <div className="w-8 h-8 border-2 border-[#F47920] border-t-transparent rounded-full animate-spin" />
            </div>
          ) : apps.length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <Users size={40} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">No applications yet. Submissions will appear here in real-time.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">#</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Name</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden md:table-cell">Mobile</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden lg:table-cell">Network</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden lg:table-cell">Current Limit</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">OTP</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide hidden sm:table-cell">Submitted</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {apps.map((app, idx) => (
                    <tr key={app.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-3 text-gray-400 text-xs">{idx + 1}</td>
                      <td className="px-4 py-3">
                        <p className="font-medium text-gray-800">{app.title} {app.first_name} {app.last_name}</p>
                        <p className="text-xs text-gray-400 flex items-center gap-1"><MapPin size={10} />{app.pin_code}</p>
                      </td>
                      <td className="px-4 py-3 hidden md:table-cell">
                        <p className="flex items-center gap-1 text-gray-600"><Phone size={12} />+91 {app.mobile_number}</p>
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell">
                        <span className="bg-gray-100 text-gray-700 px-2 py-0.5 rounded text-xs">{app.card_network || '—'}</span>
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell text-gray-600">
                        {app.current_limit ? `₹${Number(app.current_limit).toLocaleString('en-IN')}` : '—'}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium ${app.otp_verified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                          {app.otp_verified ? <CheckCircle size={10} /> : <Clock size={10} />}
                          {app.otp_verified ? 'Verified' : 'Pending'}
                        </span>
                      </td>
                      <td className="px-4 py-3 hidden sm:table-cell text-xs text-gray-400">
                        {new Date(app.submitted_at).toLocaleDateString('en-IN')}
                      </td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => setSelected(app)}
                          className="flex items-center gap-1 text-[#F47920] hover:bg-[#FFF5F0] px-2 py-1 rounded text-xs font-medium transition-colors"
                        >
                          <Eye size={12} /> View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: string | number; color: string }) {
  const colors: Record<string, string> = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600',
    yellow: 'bg-yellow-50 text-yellow-600',
    orange: 'bg-[#FFF5F0] text-[#F47920]',
  };
  return (
    <div className="bg-white rounded-lg p-4 shadow-sm">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${colors[color]}`}>{icon}</div>
      <p className="text-2xl font-bold text-gray-800">{value}</p>
      <p className="text-xs text-gray-500 mt-0.5">{label}</p>
    </div>
  );
}
