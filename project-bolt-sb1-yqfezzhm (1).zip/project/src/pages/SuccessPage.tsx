import Header from '../components/Header';
import Footer from '../components/Footer';
import { CheckCircle } from 'lucide-react';

interface Props {
  name: string;
  onNew: () => void;
}

export default function SuccessPage({ name, onNew }: Props) {
  return (
    <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
      <Header />
      <div className="flex-1 flex justify-center items-center px-4 py-6">
        <div className="bg-white rounded-lg shadow-sm w-full max-w-md p-8 text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center">
              <CheckCircle className="text-green-500" size={36} />
            </div>
          </div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">Application Submitted!</h2>
          <p className="text-sm text-gray-500 mb-1">
            Thank you, <span className="font-semibold text-gray-700">{name}</span>!
          </p>
          <p className="text-sm text-gray-500 mb-6">
            Your credit limit increase request has been received. Our team will review and get back to you within 3-5 business days.
          </p>
          <div className="bg-[#FFF5F0] rounded-lg p-4 mb-6">
            <p className="text-xs text-[#F47920] font-medium">Reference ID: BOB{Date.now().toString().slice(-8)}</p>
          </div>
          <button
            onClick={onNew}
            className="w-full bg-[#F47920] hover:bg-[#D4650A] text-white font-semibold py-3 rounded text-sm transition-colors"
          >
            Submit Another Application
          </button>
        </div>
      </div>
      <Footer />
    </div>
  );
}
