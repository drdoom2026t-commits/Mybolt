import { useState, useRef, useEffect } from 'react';
import Footer from '../components/Footer';
import Header from '../components/Header';
import { BobcardLogo } from '../components/Header';
import { Shield, CheckCircle } from 'lucide-react';

interface Props {
  mobile: string;
  onVerify: (otp: string) => void;
  onBack: () => void;
  loading?: boolean;
}

export default function Step4OTP({ mobile, onVerify, onBack, loading = false }: Props) {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [error, setError] = useState('');
  const [resendTimer, setResendTimer] = useState(30);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (resendTimer <= 0) return;
    const t = setTimeout(() => setResendTimer(s => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resendTimer]);

  function handleChange(idx: number, val: string) {
    const digit = val.replace(/\D/g, '').slice(-1);
    const next = [...otp];
    next[idx] = digit;
    setOtp(next);
    setError('');
    if (digit && idx < 5) inputRefs.current[idx + 1]?.focus();
  }

  function handleKeyDown(idx: number, e: React.KeyboardEvent) {
    if (e.key === 'Backspace' && !otp[idx] && idx > 0) inputRefs.current[idx - 1]?.focus();
  }

  function handlePaste(e: React.ClipboardEvent) {
    e.preventDefault();
    const digits = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6).split('');
    const next = [...otp];
    digits.forEach((d, i) => { if (i < 6) next[i] = d; });
    setOtp(next);
    const lastFilled = Math.min(digits.length, 5);
    inputRefs.current[lastFilled]?.focus();
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const code = otp.join('');
    if (code.length < 6) { setError('Please enter the complete 6-digit OTP'); return; }
    onVerify(code);
  }

  function handleResend() {
    if (resendTimer > 0) return;
    setOtp(['', '', '', '', '', '']);
    setError('');
    setResendTimer(30);
    inputRefs.current[0]?.focus();
  }

  const maskedMobile = mobile ? `+91 XXXXXX${mobile.slice(-4)}` : '+91 XXXXXXXXXX';

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
      <Header />
      <div className="flex-1 flex justify-center px-4 py-6">
        <div className="bg-white rounded-lg shadow-sm w-full max-w-md p-6">
          <div className="flex justify-center mb-6">
            <BobcardLogo />
          </div>

          <div className="flex justify-center mb-4">
            <div className="w-14 h-14 bg-[#FFF5F0] rounded-full flex items-center justify-center">
              <Shield className="text-[#F47920]" size={28} />
            </div>
          </div>

          <h2 className="text-center text-lg font-semibold text-gray-800 mb-2">OTP Verification</h2>
          <p className="text-center text-sm text-gray-500 mb-1">
            We've sent a 6-digit OTP to
          </p>
          <p className="text-center text-sm font-semibold text-gray-700 mb-6">{maskedMobile}</p>

          <form onSubmit={handleSubmit}>
            <div className="flex gap-2 justify-center mb-2">
              {otp.map((digit, idx) => (
                <input
                  key={idx}
                  ref={el => { inputRefs.current[idx] = el; }}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={e => handleChange(idx, e.target.value)}
                  onKeyDown={e => handleKeyDown(idx, e)}
                  onPaste={handlePaste}
                  className={`w-11 h-12 border-2 rounded text-center text-lg font-bold transition-all ${
                    digit ? 'border-[#F47920] text-[#F47920]' : 'border-gray-300 text-gray-800'
                  } focus:outline-none focus:border-[#F47920]`}
                />
              ))}
            </div>

            {error && <p className="text-red-500 text-xs text-center mb-3">{error}</p>}

            <div className="text-center mb-5">
              {resendTimer > 0 ? (
                <p className="text-sm text-gray-400">Resend OTP in <span className="text-[#F47920] font-medium">{resendTimer}s</span></p>
              ) : (
                <button type="button" onClick={handleResend} className="text-sm text-[#F47920] font-medium hover:underline">
                  Resend OTP
                </button>
              )}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#F47920] hover:bg-[#D4650A] disabled:opacity-70 text-white font-semibold py-3 rounded text-sm transition-colors flex items-center justify-center gap-2 mb-3"
            >
              {loading ? (
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <CheckCircle size={16} />
                  Verify OTP
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onBack}
              className="w-full border border-[#F47920] text-[#F47920] font-semibold py-3 rounded text-sm transition-colors hover:bg-[#FFF5F0]"
            >
              Back
            </button>
          </form>
        </div>
      </div>
      <Footer />
    </div>
  );
}
