import { useState } from 'react';
import { Shield } from 'lucide-react';
import Footer from '../components/Footer';
import Header from '../components/Header';

interface FormData {
  title: string;
  firstName: string;
  lastName: string;
  annualIncome: string;
  dateOfBirth: string;
  mobileNumber: string;
  pinCode: string;
}

interface Props {
  onNext: (data: FormData) => void;
  initialData?: Partial<FormData>;
}

export default function Step1PersonalInfo({ onNext, initialData = {} }: Props) {
  const [form, setForm] = useState<FormData>({
    title: initialData.title || '',
    firstName: initialData.firstName || '',
    lastName: initialData.lastName || '',
    annualIncome: initialData.annualIncome || '',
    dateOfBirth: initialData.dateOfBirth || '',
    mobileNumber: initialData.mobileNumber || '',
    pinCode: initialData.pinCode || '',
  });
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});

  function validate() {
    const e: Partial<Record<keyof FormData, string>> = {};
    if (!form.title) e.title = 'Required';
    if (!form.firstName.trim()) e.firstName = 'Required';
    if (!form.lastName.trim()) e.lastName = 'Required';
    if (!form.annualIncome.trim()) e.annualIncome = 'Required';
    if (!form.dateOfBirth.trim()) e.dateOfBirth = 'Required';
    if (!form.mobileNumber.trim() || form.mobileNumber.length < 10) e.mobileNumber = 'Enter valid 10-digit mobile number';
    if (!form.pinCode.trim() || form.pinCode.length < 6) e.pinCode = 'Enter valid 6-digit PIN code';
    return e;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    onNext(form);
  }

  function field(key: keyof FormData, value: string) {
    setForm(f => ({ ...f, [key]: value }));
    if (errors[key]) setErrors(e => ({ ...e, [key]: undefined }));
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
      <Header />
      <div className="flex-1 flex justify-center px-4 py-6">
        <div className="bg-white rounded-lg shadow-sm w-full max-w-md p-6">
          <p className="text-[#F47920] text-sm font-medium mb-5">All fields required unless marked 'Optional'</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Title */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Title</label>
              <div className="relative">
                <select
                  value={form.title}
                  onChange={e => field('title', e.target.value)}
                  className={`w-full border rounded px-3 py-2.5 text-sm appearance-none bg-white pr-8 ${errors.title ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
                >
                  <option value="">Select</option>
                  <option value="Mr">Mr</option>
                  <option value="Mrs">Mrs</option>
                  <option value="Ms">Ms</option>
                  <option value="Dr">Dr</option>
                </select>
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">▼</span>
              </div>
              {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
            </div>

            {/* First Name */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">First Name</label>
              <input
                type="text"
                placeholder="First Name"
                value={form.firstName}
                onChange={e => field('firstName', e.target.value)}
                className={`w-full border rounded px-3 py-2.5 text-sm ${errors.firstName ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              <p className="text-xs text-gray-400 mt-1">Ensure name is as per PAN</p>
              {errors.firstName && <p className="text-red-500 text-xs">{errors.firstName}</p>}
            </div>

            {/* Last Name */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Last Name</label>
              <input
                type="text"
                placeholder="Last Name"
                value={form.lastName}
                onChange={e => field('lastName', e.target.value)}
                className={`w-full border rounded px-3 py-2.5 text-sm ${errors.lastName ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              {errors.lastName && <p className="text-red-500 text-xs mt-1">{errors.lastName}</p>}
            </div>

            {/* Annual Income */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Annual Income</label>
              <input
                type="number"
                placeholder="Annual Income"
                value={form.annualIncome}
                onChange={e => field('annualIncome', e.target.value)}
                className={`w-full border rounded px-3 py-2.5 text-sm ${errors.annualIncome ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              {errors.annualIncome && <p className="text-red-500 text-xs mt-1">{errors.annualIncome}</p>}
            </div>

            {/* Date of Birth */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Date of Birth</label>
              <input
                type="text"
                placeholder="DD/MM/YYYY"
                value={form.dateOfBirth}
                onChange={e => field('dateOfBirth', e.target.value)}
                maxLength={10}
                className={`w-full border rounded px-3 py-2.5 text-sm ${errors.dateOfBirth ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              {errors.dateOfBirth && <p className="text-red-500 text-xs mt-1">{errors.dateOfBirth}</p>}
            </div>

            {/* Mobile Number */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Mobile Number (Aadhaar Linked)</label>
              <div className="flex">
                <span className="border border-r-0 border-gray-300 rounded-l px-3 py-2.5 text-sm text-gray-500 bg-gray-50">+91</span>
                <input
                  type="tel"
                  placeholder="Mobile Number"
                  value={form.mobileNumber}
                  onChange={e => field('mobileNumber', e.target.value.replace(/\D/g, '').slice(0, 10))}
                  className={`flex-1 border rounded-r px-3 py-2.5 text-sm ${errors.mobileNumber ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
                />
              </div>
              <div className="flex items-center gap-1 mt-1">
                <Shield size={12} className="text-green-500" />
                <span className="text-xs text-gray-400">Your privacy is protected</span>
              </div>
              {errors.mobileNumber && <p className="text-red-500 text-xs">{errors.mobileNumber}</p>}
            </div>

            {/* PIN Code */}
            <div>
              <label className="block text-sm text-gray-700 mb-1">Current Address PIN Code</label>
              <input
                type="text"
                placeholder="Enter PIN code"
                value={form.pinCode}
                onChange={e => field('pinCode', e.target.value.replace(/\D/g, '').slice(0, 6))}
                className={`w-full border rounded px-3 py-2.5 text-sm ${errors.pinCode ? 'border-red-400' : 'border-gray-300'} focus:outline-none focus:border-[#F47920]`}
              />
              {errors.pinCode && <p className="text-red-500 text-xs mt-1">{errors.pinCode}</p>}
            </div>

            <button
              type="submit"
              className="w-full bg-[#F47920] hover:bg-[#D4650A] text-white font-semibold py-3 rounded text-sm transition-colors"
            >
              Proceed
            </button>
          </form>
        </div>
      </div>
      <Footer />
    </div>
  );
}
