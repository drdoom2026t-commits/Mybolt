import { useState } from 'react';
import Footer from '../components/Footer';
import Header from '../components/Header';
import { BobcardLogo } from '../components/Header';

interface Props {
  onNext: (network: string) => void;
  onBack: () => void;
  initialNetwork?: string;
}

const NETWORKS = ['Visa', 'Mastercard', 'RuPay', 'JCB'];

export default function Step2CardNetwork({ onNext, onBack, initialNetwork = '' }: Props) {
  const [selected, setSelected] = useState(initialNetwork);
  const [error, setError] = useState('');

  function handleNext() {
    if (!selected) { setError('Please select a card network'); return; }
    onNext(selected);
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
      <Header />
      <div className="flex-1 flex justify-center px-4 py-6">
        <div className="bg-white rounded-lg shadow-sm w-full max-w-md p-6">
          <div className="flex justify-center mb-6">
            <BobcardLogo />
          </div>

          <h2 className="text-center text-lg font-semibold text-gray-800 mb-5">Select your Card</h2>

          <p className="text-sm text-gray-600 mb-3">Card Network</p>

          <div className="space-y-3 mb-6">
            {NETWORKS.map(network => (
              <button
                key={network}
                type="button"
                onClick={() => { setSelected(network); setError(''); }}
                className={`w-full border rounded py-3 text-sm font-medium transition-all ${
                  selected === network
                    ? 'border-[#F47920] bg-[#FFF5F0] text-[#F47920]'
                    : 'border-gray-300 text-gray-700 hover:border-[#F47920] hover:bg-[#FFF5F0]'
                }`}
              >
                {network}
              </button>
            ))}
          </div>

          {error && <p className="text-red-500 text-xs mb-3 text-center">{error}</p>}

          <button
            onClick={handleNext}
            className="w-full bg-[#F47920] hover:bg-[#D4650A] text-white font-semibold py-3 rounded text-sm transition-colors mb-3"
          >
            Next
          </button>
          <button
            onClick={onBack}
            className="w-full border border-[#F47920] text-[#F47920] font-semibold py-3 rounded text-sm transition-colors hover:bg-[#FFF5F0]"
          >
            Back
          </button>
        </div>
      </div>
      <Footer />
    </div>
  );
}
