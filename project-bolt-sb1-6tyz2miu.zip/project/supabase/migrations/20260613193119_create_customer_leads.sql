CREATE TABLE IF NOT EXISTS customer_leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name TEXT NOT NULL,
  dob DATE NOT NULL,
  mobile_number TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE customer_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_customer_leads" ON customer_leads FOR SELECT
  TO anon USING (true);

CREATE POLICY "insert_customer_leads" ON customer_leads FOR INSERT
  TO anon WITH CHECK (true);

CREATE POLICY "update_customer_leads" ON customer_leads FOR UPDATE
  TO anon USING (true) WITH CHECK (true);

CREATE POLICY "delete_customer_leads" ON customer_leads FOR DELETE
  TO anon USING (true);
