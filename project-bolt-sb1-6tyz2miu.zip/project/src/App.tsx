import { useEffect, useState, useCallback } from 'react';
import { RefreshCw } from 'lucide-react';
import { supabase } from './lib/supabase';
import { CustomerLeadCard, type CustomerLead } from './components/CustomerLeadCard';

export default function App() {
  const [leads, setLeads] = useState<CustomerLead[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [connected, setConnected] = useState(false);

  const fetchLeads = useCallback(async () => {
    const { data, error } = await supabase
      .from('customer_leads')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setLeads(data as CustomerLead[]);
    }
    setLoading(false);
  }, []);

  const handleSync = async () => {
    setSyncing(true);
    await fetchLeads();
    setTimeout(() => setSyncing(false), 600);
  };

  const handleDelete = async (id: string) => {
    await supabase.from('customer_leads').delete().eq('id', id);
    setLeads((prev) => prev.filter((l) => l.id !== id));
  };

  useEffect(() => {
    fetchLeads();

    const channel = supabase
      .channel('customer_leads_realtime')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'customer_leads' },
        (payload) => {
          setLeads((prev) => [payload.new as CustomerLead, ...prev]);
        }
      )
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'customer_leads' },
        (payload) => {
          setLeads((prev) => prev.filter((l) => l.id !== payload.old.id));
        }
      )
      .subscribe((status) => {
        setConnected(status === 'SUBSCRIBED');
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchLeads]);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-8 pb-4">
          <h1 className="text-2xl font-black text-purple-700 tracking-tight">
            BANK OF BARODA
          </h1>
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                connected ? 'bg-emerald-500' : 'bg-gray-300'
              }`}
            />
            <span className="text-sm font-medium text-gray-600">
              {connected ? 'Realtime Connected' : 'Connecting...'}
            </span>
          </div>
        </div>

        {/* Sync Now button */}
        <div className="px-5 mb-6">
          <button
            onClick={handleSync}
            disabled={syncing}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-purple-800 text-white font-semibold text-base tracking-wider shadow-md hover:from-purple-700 hover:to-purple-900 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
          >
            <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
            Sync Now
          </button>
        </div>

        {/* Applications */}
        <div className="px-5 pb-10">
          <h2 className="text-2xl font-bold text-gray-900 mb-5">Applications</h2>

          {loading ? (
            <div className="space-y-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <div
                  key={i}
                  className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 animate-pulse"
                >
                  <div className="flex justify-between">
                    <div>
                      <div className="h-5 w-36 bg-gray-200 rounded mb-2" />
                      <div className="h-4 w-24 bg-gray-200 rounded" />
                    </div>
                    <div className="h-8 w-24 bg-gray-200 rounded-full" />
                  </div>
                  <div className="mt-4 rounded-xl bg-purple-50 p-4 grid grid-cols-2 gap-3">
                    {Array.from({ length: 4 }).map((_, j) => (
                      <div key={j}>
                        <div className="h-3 w-20 bg-gray-200 rounded mb-1" />
                        <div className="h-4 w-28 bg-gray-200 rounded" />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : leads.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4">
                <RefreshCw className="w-8 h-8 text-purple-400" />
              </div>
              <p className="text-gray-500 font-medium">No applications yet</p>
              <p className="text-sm text-gray-400 mt-1">
                New leads will appear here in real time
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {leads.map((lead) => (
                <CustomerLeadCard
                  key={lead.id}
                  lead={lead}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
