import { createClient } from '@supabase/supabase-js';

const rawUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

// If the URL isn't a standard https URL, derive project URL from the JWT ref claim
function resolveSupabaseUrl(url: string, key: string): string {
  if (url.startsWith('https://')) return url;
  try {
    const payload = JSON.parse(atob(key.split('.')[1]));
    if (payload.ref) return `https://${payload.ref}.supabase.co`;
  } catch {
    // fall through
  }
  return url;
}

const supabaseUrl = resolveSupabaseUrl(rawUrl, supabaseAnonKey);

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
