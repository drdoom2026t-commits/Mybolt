import { Trash2 } from 'lucide-react';

export interface CustomerLead {
  id: string;
  customer_name: string;
  dob: string;
  mobile_number: string;
  created_at: string;
}

interface CustomerLeadCardProps {
  lead: CustomerLead;
  onDelete: (id: string) => void;
}

function formatDob(dob: string): string {
  if (!dob) return '—';
  const [year, month, day] = dob.split('-');
  return `${day}/${month}/${year}`;
}

function formatTimestamp(ts: string): string {
  if (!ts) return '—';
  const d = new Date(ts);
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });
}

export function CustomerLeadCard({ lead, onDelete }: CustomerLeadCardProps) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="px-5 pt-5 pb-4">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-gray-900 tracking-wide">
              {lead.customer_name}
            </h2>
            <p className="text-gray-500 mt-0.5 text-sm">{lead.mobile_number}</p>
          </div>
          <div className="flex flex-col items-end gap-2 shrink-0">
            <span className="px-4 py-1.5 rounded-full border-2 border-purple-600 text-purple-700 font-bold text-xs tracking-widest">
              NEW LEAD
            </span>
            <button
              onClick={() => onDelete(lead.id)}
              className="flex items-center gap-1.5 text-red-500 hover:text-red-700 text-sm font-semibold transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              Delete
            </button>
          </div>
        </div>
      </div>

      <div className="mx-4 mb-4 rounded-xl bg-purple-50 px-5 py-4 grid grid-cols-2 gap-x-6 gap-y-4">
        <div>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-0.5">
            Mobile Number
          </p>
          <p className="text-base font-semibold text-gray-800">{lead.mobile_number}</p>
        </div>
        <div>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-0.5">
            Date of Birth
          </p>
          <p className="text-base font-semibold text-gray-800">{formatDob(lead.dob)}</p>
        </div>
        <div className="col-span-2">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-0.5">
            Submission Time
          </p>
          <p className="text-base font-semibold text-gray-800">{formatTimestamp(lead.created_at)}</p>
        </div>
        <div>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-0.5">
            Status
          </p>
          <p className="text-base font-bold text-emerald-600">LIVE</p>
        </div>
      </div>
    </div>
  );
}
